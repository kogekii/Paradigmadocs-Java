package Proyectolab3;
import java.util.ArrayList;

public class Docs {
    int ID;
    String namedoc;
    String textdoc; 
    Fecha creacion;
    Fecha modificacion;
    ArrayList<Integer> oldverions;
    
    
}
