
package Proyectolab3;
//import java.util.ArrayList;

//import java.util.ArrayList;


public class App {
    public static void main(String[] args){
        Editor p = new Editor();
        p.Crear_plataforma("panda", 07, 01, 2022);
        p.Register("andy", "hola123");
        p.Register("Ale", "sdasd");
        System.out.printf("%d" , p.usuarios.get(0).GetID()); 
    } 
}
